package com.service;

import com.model.Student;

public interface SeviceI {

	
	 void addStudentData(Student student);
	
}
