package com.dao;

import com.model.Student;

public interface DaoI {

	void addStudentData(Student student);
}
