package com.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Student;

@WebServlet(urlPatterns = "/reg")
public class RegisterServlet extends HttpServlet{

	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Register Servlet Called");
		
		String id1=request.getParameter("sid");
		int id=Integer.parseInt(id1);
		
		String name=request.getParameter("sname");
		
		String address=request.getParameter("saddress");
		
		String salary=request.getParameter("salary");
		double salary1=Double.parseDouble(salary);
		
		String uname=request.getParameter("suname");
		
		String pass=request.getParameter("spass");
		
		Student s=new Student();
		s.setSid(id);
		s.setSname(name);
		s.setSaddress(address);
		s.setSalary(salary1);
		s.setSuname(uname);
		s.setSpass(pass);
		System.out.println(" Data of Student :  " + s);
		
		request.setAttribute("student", s);
		 
		RequestDispatcher rd=request.getRequestDispatcher("success.jsp");
		rd.forward(request, response);
		
	}
}
